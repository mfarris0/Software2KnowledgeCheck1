﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Software2KnowledgeCheck1
{
    internal class MaterialsRepo
    {
        public List<string> GetMaterials() => new List<string>();
    }
}
